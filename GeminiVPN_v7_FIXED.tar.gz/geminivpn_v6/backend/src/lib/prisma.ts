/**
 * Prisma Singleton — GeminiVPN
 *
 * WHY THIS FILE EXISTS:
 *   SQLite opens the database file as a single-writer, multi-reader store.
 *   Creating multiple PrismaClient instances in different modules is fine for
 *   PostgreSQL (connection pool), but with SQLite it means multiple open file
 *   handles, each with their own write queue.  Under any concurrent traffic
 *   this causes "SQLITE_BUSY: database is locked" crashes.
 *
 *   Every module MUST import `prisma` from this file — never `new PrismaClient()`.
 *
 * ALSO: We enable WAL (Write-Ahead Logging) mode on first connect so that
 *   readers don't block writers and vice-versa.  This dramatically improves
 *   performance under the moderate concurrency a VPN management backend sees.
 */

import { PrismaClient } from '@prisma/client';
import { logger } from '../utils/logger';

declare global {
  // Prevents TypeScript from complaining about the global variable
  // eslint-disable-next-line no-var
  var __prisma: PrismaClient | undefined;
}

function makePrismaClient(): PrismaClient {
  const client = new PrismaClient({
    log:
      process.env.NODE_ENV === 'development'
        ? ['query', 'info', 'warn', 'error']
        : ['error'],
  });

  // Enable WAL mode and optimise SQLite for production concurrency.
  // These pragmas are idempotent and safe to re-apply on restart.
  client.$connect().then(async () => {
    try {
      await client.$executeRawUnsafe(`PRAGMA journal_mode = WAL;`);
      await client.$executeRawUnsafe(`PRAGMA synchronous  = NORMAL;`);
      await client.$executeRawUnsafe(`PRAGMA foreign_keys = ON;`);
      await client.$executeRawUnsafe(`PRAGMA busy_timeout = 5000;`);
      logger.info('✅ SQLite pragmas applied (WAL mode, 5s busy-timeout)');
    } catch (err) {
      logger.warn('⚠️  Could not apply SQLite pragmas (non-fatal):', err);
    }
  }).catch(() => {
    // $connect() may be retried by the caller — ignore error here.
  });

  return client;
}

// Re-use the same instance across hot-reloads in development,
// create once in production.
const prisma: PrismaClient =
  global.__prisma ?? (global.__prisma = makePrismaClient());

export default prisma;
