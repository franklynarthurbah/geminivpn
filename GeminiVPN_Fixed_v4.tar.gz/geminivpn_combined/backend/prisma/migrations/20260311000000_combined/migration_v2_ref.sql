-- =============================================================================
-- GeminiVPN Migration: 20260311000000_payment_refactor
-- Purpose: Replace all Stripe-specific columns with provider-agnostic ones.
-- Safe for: fresh installs AND existing databases with Stripe data.
-- Run: prisma migrate deploy  (applied automatically by geminivpn.sh)
-- =============================================================================

-- 1. Create PaymentProvider enum (idempotent)
DO $$ BEGIN
  CREATE TYPE "PaymentProvider" AS ENUM ('SQUARE', 'PADDLE', 'COINBASE');
EXCEPTION WHEN duplicate_object THEN NULL;
END $$;

-- ── User table changes ────────────────────────────────────────────────────────

-- 2. Add new provider-agnostic columns to User (idempotent with IF NOT EXISTS)
ALTER TABLE "User"
  ADD COLUMN IF NOT EXISTS "paymentCustomerId"    TEXT,
  ADD COLUMN IF NOT EXISTS "paddleSubscriptionId" TEXT,
  ADD COLUMN IF NOT EXISTS "paymentProvider"      "PaymentProvider";

-- 3. Migrate any existing Stripe customer IDs into the new generic column
--    so no live user data is lost during the upgrade.
UPDATE "User"
SET    "paymentCustomerId" = "stripeCustomerId"
WHERE  "stripeCustomerId"  IS NOT NULL
  AND  "paymentCustomerId" IS NULL;

-- 4. Add unique constraints on new columns
DO $$ BEGIN
  ALTER TABLE "User" ADD CONSTRAINT "User_paymentCustomerId_key"    UNIQUE ("paymentCustomerId");
EXCEPTION WHEN duplicate_table THEN NULL;
END $$;
DO $$ BEGIN
  ALTER TABLE "User" ADD CONSTRAINT "User_paddleSubscriptionId_key" UNIQUE ("paddleSubscriptionId");
EXCEPTION WHEN duplicate_table THEN NULL;
END $$;

-- 5. Drop Stripe columns (data already migrated above)
ALTER TABLE "User"
  DROP COLUMN IF EXISTS "stripeCustomerId",
  DROP COLUMN IF EXISTS "stripeSubscriptionId";

-- ── Payment table changes ─────────────────────────────────────────────────────

-- 6. Add new columns to Payment
ALTER TABLE "Payment"
  ADD COLUMN IF NOT EXISTS "providerPaymentId" TEXT,
  ADD COLUMN IF NOT EXISTS "provider"          "PaymentProvider",
  ADD COLUMN IF NOT EXISTS "metadata"          TEXT;

-- 7. Migrate existing Stripe payment IDs
UPDATE "Payment"
SET    "providerPaymentId" = "stripePaymentId"
WHERE  "stripePaymentId"   IS NOT NULL
  AND  "providerPaymentId" IS NULL;

-- 8. Unique constraint on providerPaymentId
DO $$ BEGIN
  ALTER TABLE "Payment" ADD CONSTRAINT "Payment_providerPaymentId_key" UNIQUE ("providerPaymentId");
EXCEPTION WHEN duplicate_table THEN NULL;
END $$;

-- 9. Drop old Stripe column (safe — migrated above)
ALTER TABLE "Payment"
  DROP COLUMN IF EXISTS "stripePaymentId";

-- ── Indexes ───────────────────────────────────────────────────────────────────
CREATE INDEX IF NOT EXISTS "Payment_userId_idx"   ON "Payment" ("userId");
CREATE INDEX IF NOT EXISTS "Payment_provider_idx" ON "Payment" ("provider");
CREATE INDEX IF NOT EXISTS "Payment_status_idx"   ON "Payment" ("status");
