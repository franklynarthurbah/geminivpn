-- GeminiVPN v3 Combined Migration
-- Adds all-provider payment support while preserving existing data

-- PaymentProvider enum (all 4 providers)
DO $$ BEGIN
  CREATE TYPE "PaymentProvider" AS ENUM ('STRIPE', 'SQUARE', 'PADDLE', 'COINBASE');
EXCEPTION WHEN duplicate_object THEN
  -- Add new values if enum exists but is missing them
  BEGIN ALTER TYPE "PaymentProvider" ADD VALUE 'STRIPE';   EXCEPTION WHEN duplicate_object THEN null; END;
  BEGIN ALTER TYPE "PaymentProvider" ADD VALUE 'SQUARE';   EXCEPTION WHEN duplicate_object THEN null; END;
  BEGIN ALTER TYPE "PaymentProvider" ADD VALUE 'PADDLE';   EXCEPTION WHEN duplicate_object THEN null; END;
  BEGIN ALTER TYPE "PaymentProvider" ADD VALUE 'COINBASE'; EXCEPTION WHEN duplicate_object THEN null; END;
END $$;

-- User: add multi-provider fields (idempotent)
ALTER TABLE "User"
  ADD COLUMN IF NOT EXISTS "paymentCustomerId"    TEXT UNIQUE,
  ADD COLUMN IF NOT EXISTS "paddleSubscriptionId" TEXT UNIQUE,
  ADD COLUMN IF NOT EXISTS "paymentProvider"      "PaymentProvider";

-- Payment: add multi-provider fields (idempotent)
ALTER TABLE "Payment"
  ADD COLUMN IF NOT EXISTS "providerPaymentId" TEXT UNIQUE,
  ADD COLUMN IF NOT EXISTS "provider"          "PaymentProvider",
  ADD COLUMN IF NOT EXISTS "metadata"          TEXT;

-- Make provider optional on payment (was required in init)
ALTER TABLE "Payment" ALTER COLUMN "provider" DROP NOT NULL;

-- Indexes
CREATE INDEX IF NOT EXISTS "Payment_userId_idx"   ON "Payment"("userId");
CREATE INDEX IF NOT EXISTS "Payment_provider_idx" ON "Payment"("provider");
CREATE INDEX IF NOT EXISTS "Payment_status_idx"   ON "Payment"("status");
