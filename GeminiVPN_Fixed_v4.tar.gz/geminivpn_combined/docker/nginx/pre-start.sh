#!/bin/sh
# GeminiVPN nginx pre-start — ensures nginx starts even without LE cert
# Fixed: removed -addext (requires OpenSSL 1.1.1+), using -subj only
set -e

DOMAIN="geminivpn.zapto.org"
LE_CERT="/etc/letsencrypt/live/${DOMAIN}/fullchain.pem"
LE_KEY="/etc/letsencrypt/live/${DOMAIN}/privkey.pem"
SS_DIR="/etc/nginx/ssl"

echo "[nginx-entrypoint] Checking SSL certificate..."

if [ -f "$LE_CERT" ] && [ -f "$LE_KEY" ]; then
    echo "[nginx-entrypoint] Let's Encrypt cert found."
else
    echo "[nginx-entrypoint] Generating self-signed fallback cert..."
    mkdir -p "$SS_DIR"
    mkdir -p "/etc/letsencrypt/live/${DOMAIN}"

    # Generate self-signed cert without -addext (compatible with all OpenSSL versions)
    openssl req -x509 -nodes -days 3650 \
        -newkey rsa:2048 \
        -keyout "${SS_DIR}/self-signed.key" \
        -out    "${SS_DIR}/self-signed.crt" \
        -subj   "/C=US/ST=State/L=City/O=GeminiVPN/CN=${DOMAIN}" \
        2>/dev/null || {
            echo "[nginx-entrypoint] ERROR: openssl failed"
            exit 1
        }

    ln -sf "${SS_DIR}/self-signed.crt" "$LE_CERT"
    ln -sf "${SS_DIR}/self-signed.key" "$LE_KEY"
    echo "[nginx-entrypoint] Self-signed cert ready."
fi

mkdir -p /var/www/geminivpn /var/www/certbot

if [ ! -f "/var/www/geminivpn/index.html" ]; then
    cat > /var/www/geminivpn/index.html << 'HTML'
<!DOCTYPE html><html><head><meta charset="UTF-8"><title>GeminiVPN</title>
<style>*{margin:0;padding:0}body{background:#04080F;color:#fff;font-family:sans-serif;display:flex;align-items:center;justify-content:center;height:100vh;flex-direction:column;text-align:center}h1{color:#00EFFF;font-size:2rem;margin:1rem 0}p{color:rgba(255,255,255,.6)}</style>
</head><body><h1>GeminiVPN</h1><p>Initializing...</p></body></html>
HTML
fi

echo "[nginx-entrypoint] Starting nginx..."
exec /docker-entrypoint.sh nginx -g "daemon off;"
